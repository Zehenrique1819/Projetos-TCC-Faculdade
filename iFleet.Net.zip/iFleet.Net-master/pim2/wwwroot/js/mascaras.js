﻿$(document).ready(function () {
    $('.mask-cpf').mask('000.000.000-00', { reverse: true });
    $('.money').mask('000,000,000,000,000.00', { reverse: true });
    $('.prateleira').mask('AA-AA', { reverse: true });
    //$('.cep').mask('00000-000');
});